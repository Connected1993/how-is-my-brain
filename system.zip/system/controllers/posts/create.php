<?php
/**
 * Created by PhpStorm.
 * User: Timondecathlon
 * Date: 17.01.2020
 * Time: 22:17
 */

ini_set('error_reporting', E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

require_once('../../../global_pass.php');

$table = $_POST['table'];
$user = new Post();
$user->getTable($table);

$fields =[];
$values =[];

foreach($_POST as $key=>$value){
    if($key != 'table') {
        $fields[] = $key;
        $values[] = $value;
    }
}

var_dump($_POST);

$user->createLine($fields,$values);