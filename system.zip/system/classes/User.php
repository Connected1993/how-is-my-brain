<?php
/**
 * Created by PhpStorm.
 * User: Timondecathlon
 * Date: 17.01.2020
 * Time: 21:39
 */
class User extends Post
{
    public function setTable(){
        return 'users';
    }

    public static function drochka(){
        echo ' я дрочу';

    }
}