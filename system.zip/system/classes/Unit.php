<?php
abstract class Unit implements UnitActions
{
	protected $pdo; // Идентификатор соединения
    protected $id;
    public $bdata; 

	/*конструктор, подключающийся к базе данных, устанавливающий локаль и кодировку соединения */
	public function __construct(int $id = null ) {
		$this->id = $id;
        $this->pdo = new \PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME, DB_USER, DB_PASSWORD);
        $this->pdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
        $this->pdo->exec("set names utf8");    
	}

    abstract public function setTable();


    public function getLine()
    {
        $sql = $this->pdo->prepare("SELECT * FROM ".$this->setTable()." WHERE id='".$this->id."'");
        $sql->execute();
        $this->bdata =  $sql->fetch(PDO::FETCH_LAZY);
        return $this->bdata;
    }

    public function getField($field)
    {
        if(!$this->bdata){
            $this->getLine();
        }
        return trim($this->bdata->$field);
    }

    public function updateField($field, $param){
        $sql = $this->pdo->prepare("UPDATE ".$this->setTable()." SET $field=:param WHERE id=:id");
        $sql->bindParam(':param', $param);
        $sql->bindParam(':id', $this->id);      
        if($sql->execute()){
                return true;
        }     
        return false;
    }

    public function createLine($fields_array, $values_array){
        $fields_str = implode(',',$fields_array);
        $placeholders_str = '';
        foreach ($fields_array as $key=>$value) {
            $placeholders_str .= ":$value,";
        }
        $sql = $this->pdo->prepare("INSERT INTO ".$this->setTable()."($fields_str)VALUES(".trim($placeholders_str,',').") ");
        foreach($fields_array as $key=>$value){
            $sql->bindParam(":$fields_array[$key]", $values_array[$key]);
        }
        try {
            $sql->execute();
            $this->id = $this->pdo->lastInsertId();
            return $this->id;
        }catch (PDOException $e) {
            echo 'Подключение не удалось: ' . $e->getMessage();
        }
        return 0;
    }

    public function updateLine($fields_array, $values_array){
        $update_str = '';
        foreach($fields_array as $key=>$value){
                $update_str .= "$value=:$value,";
        }
        $sql = $this->pdo->prepare("UPDATE ".$this->setTable()." SET ".trim($update_str,',')."  WHERE id=".$this->id);
        foreach($fields_array as $key=>$value){
            $sql->bindParam(":$value", $values_array[$key]);
        }
        try {
            $sql->execute();
            $this->pdo->errorInfo();
            return $this->getField('id');
        }catch (PDOException $e) {
            echo 'Подключение не удалось: ' . $e->getMessage();
        }
        return 0;
    }

    public function deleteLine(){
        $sql = $this->pdo->prepare("DELETE FROM ".$this->setTable()." WHERE id=:id");
        $sql->bindParam(':id', $this->id);
        try {
            $post_id = $this->getField('id');
            $sql->execute();
            return $post_id;
        }catch (PDOException $e) {
            echo 'Подключение не удалось: ' . $e->getMessage();
        }
        return 0;
    }

}


