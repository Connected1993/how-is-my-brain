<?
class Post extends Unit
{
    protected $table; 

    //Получаем таблицу поста с которой работать и ее проверяем
    public function getTable($table){ 
       $this->table = $table; 
    }

    //выозвращаем имя базы при подключении к БД
    public function setTable(){
        return $this->table;
    }

    public function title(){
        return $this->getField('title');
    }

    public function description(){
        return $this->getField('description');
    }
 
    
}


?>